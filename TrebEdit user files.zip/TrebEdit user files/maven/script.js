// Firebase Config (Replace if needed)
const firebaseConfig = {
  apiKey: "AIzaSyBVCpH_IhvQh-tlycvYM6CDsphU3Gz0qJQ",
  authDomain: "mavenchat-37f53.firebaseapp.com",
  projectId: "mavenchat-37f53",
  storageBucket: "mavenchat-37f53.firebasestorage.app",
  messagingSenderId: "483683143861",
  appId: "1:483683143861:web:926b91f8ea7ab80ca82efc",
  measurementId: "G-7XMVJ7LXT8"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Set username
const username = localStorage.getItem("mavenchat_user") || "Guest";
document.getElementById("userLabel").innerText = "Logged in as " + username;

const chatWindow = document.getElementById("chatWindow");
const messageInput = document.getElementById("messageInput");
const messagesRef = db.collection("messages");

function addMessageToUI(sender, text) {
  const msg = document.createElement("div");
  msg.classList.add("message", sender === "bot" ? "bot" : "user");
  msg.innerText = text;
  chatWindow.appendChild(msg);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

async function sendMessage() {
  const text = messageInput.value.trim();
  if (!text) return;

  messageInput.value = "";
  await messagesRef.add({
    user: username,
    text,
    sender: "user",
    timestamp: firebase.firestore.FieldValue.serverTimestamp()
  });

  addMessageToUI("user", text);
  getBotReply(text);
}

async function getBotReply(userText) {
  addMessageToUI("bot", "Typing...");

  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
  method: "POST",
  headers: {
    "Authorization": "Bearer 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",
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    model: "gpt-3.5-turbo",
    messages: [{ role: "user", content: userText }]
  })
});
    const data = await res.json();
    const reply = data.choices[0].message.content;

    await messagesRef.add({
      user: "Maven AI",
      text: reply,
      sender: "bot",
      timestamp: firebase.firestore.FieldValue.serverTimestamp()
    });

    addMessageToUI("bot", reply);
  } catch (err) {
    addMessageToUI("bot", "⚠️ Failed to reply.");
  }
}

// Load and listen for messages
messagesRef.orderBy("timestamp").onSnapshot(snapshot => {
  chatWindow.innerHTML = "";
  snapshot.forEach(doc => {
    const m = doc.data();
    addMessageToUI(m.sender, m.text);
  });
});