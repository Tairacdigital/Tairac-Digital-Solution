<script>
  const firebaseConfig = {
    apiKey: "AIzaSyBVCpH_IhvQh-tlycvYM6CDsphU3Gz0qJQ",
    authDomain: "mavenchat-37f53.firebaseapp.com",
    projectId: "mavenchat-37f53",
    storageBucket: "mavenchat-37f53.firebasestorage.app",
    messagingSenderId: "483683143861",
    appId: "1:483683143861:web:926b91f8ea7ab80ca82efc",
    measurementId: "G-7XMVJ7LXT8"
  };
  firebase.initializeApp(firebaseConfig);
</script>